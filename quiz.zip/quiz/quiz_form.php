<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Class assignment</title>
</head>
<body>
        <form action="quiz.php" method= "GET">
            <select name="Users" multiple size="5">
                <option value="Kwame">Kwame</option>
                <option value="Ama">Ama</option>
                <option value="Akua">Akua</option>
                <option value="Greta">Greta</option>
                <input type="submit" value="submit">
            </select>


            <form action="quiz.php" method= "GET">
                <select name="Preference" multiple size="5">
                    <option value="Rice">Rice</option>
                    <option value="Sadza">Sadza</option>
                    <option value="Banku">Banku</option>
                    <option value="Indomie">Indomie</option>
                    <input type="submit" value="submit">
            </select>

     </body>
</html>